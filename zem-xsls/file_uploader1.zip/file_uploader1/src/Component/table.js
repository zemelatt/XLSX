import { Button, Form, Input, Popconfirm, Space, Table, Tag } from "antd";
import React, { useContext, useEffect, useRef, useState } from "react";

import Axios from "axios";

import { EditOutlined, DeleteOutlined } from "@ant-design/icons";

const data = [
  {
    key: "1",
    Description: "John Brown",
    Qty: 32,
    Rate: "New York No. 1 Lake Park",
    Amount: ["nice", "developer"],
  },
  {
    key: "2",
    Description: "Jim Green",
    Qty: 42,
    Rate: "London No. 1 Lake Park",
    Amount: ["loser"],
  },
  {
    key: "3",
    Description: "Joe Black",
    Qty: 32,
    Rate: "Sydney No. 1 Lake Park",
    Amount: ["cool", "teacher"],
  },
];
const App = () => {
  const [file, setFile] = useState(data);

  const columns = [
    {
      title: "Description",
      dataIndex: "Description",
      key: "Description",
      render: (text) => <p>{text}</p>,
    },
    {
      title: "Qty",
      dataIndex: "Qty",
      key: "Qty",
    },
    {
      title: "Rate",
      dataIndex: "Rate",
      key: "Rate",
    },
    {
      title: "Amount",
      dataIndex: "Amount",
      key: "Amount",
    },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <EditOutlined
            onClick={() => {
              onEdit(record);
            }}
          />

          <DeleteOutlined
            onClick={() => {
              onDelete(record.id);
            }}
          />
        </Space>
      ),
    },
  ];
  const onEdit = (record) => {};
  const onDelete = (record) => {
    Axios.delete(`http://localhost:2211/deleteTask${record}`, {
      withCredentials: true,
    }).then((response) => {
      setFile([...file]);
    });
  };

  return (
    <>
      <Table columns={columns} dataSource={file} />
    </>
  );
};
export default App;
