import React from "react";
//css
import "./App.css";
import File from "./Page/fileUpload";
const App = () => {
  return (
    <div>
      <File />
    </div>
  );
};

export default App;

// import logo from "./logo.svg";
// import "./App.css";
// import { Upload, Button, Spin } from "antd";
// import { useState } from "react";
// import Axios from "axios";
// import * as XLSX from "xlsx";

// function App() {
//   // const [files, setFiles] = useState("");
//   const [data, setData] = useState([]);
//   const [file, setFile] = useState("");

//   const getFile = (e) => {
//     setFile(e.target.files[0]);
//     const reader = new FileReader();
//     reader.readAsBinaryString(e.target.files[0]);
//     reader.onload = (e) => {
//       const data = e.target.result;
//       const workbook = XLSX.read(data, { type: "binary" });
//       const sheetName = workbook.SheetNames[0];
//       const sheet = workbook.Sheets[sheetName];
//       const parseData = XLSX.utils.sheet_to_json(sheet);
//       setData(parseData);

//       // setFiles(e.target.files[0]);
//     };
//   };
//   const Submit = (e) => {
//     e.preventDefault();
// let formData = new FormData();
// formData.append("img", file);
//     Axios.post("http://localhost:2211/get", formData, {
//       withCredentials: true,
//     }).then((response) => {
//       if (response) {
//         console.log("get it");

//       } else {
//         console.log("err");
//       }
//     });
//   };

//   return (
//     <div className="App">
//       <form>
//         <input
//           type="file"
//           accept=".xlsx, .xsl,"
//           name="img"
//           onChange={getFile}
//         />
//         <button type="submit" onClick={Submit}>
//           submit
//         </button>
//       </form>
//       <div className="container">
//         {data.length > 0 && (
//           <table class="table table-striped">
//             <thead>
//               <tr>
//                 {Object.keys(data[0]).map((key) => (
//                   <th key={key}>{/* {key} */}</th>
//                 ))}
//               </tr>
//             </thead>
//             <tbody>
//               {data.map((row, index) => (
//                 <tr key={index}>
//                   {Object.values(row).map((value, index) => (
//                     <td key={index}>{value}</td>
//                   ))}
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         )}
//       </div>
//     </div>
//   );
// }

// export default App;
