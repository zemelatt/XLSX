//antd
import { UploadOutlined } from "@ant-design/icons";
import { Form, Row, Col, Button, message, Upload } from "antd";

//axios
import Axios from "axios";
//table component
import Table from "../Component/table";

const SubmitFile = (values) => {
  let data = new FormData();
  data.append("image-file", [values.imageFile.file.originFileObj]);
  Axios.post("http://localhost:8080/uploadTasks", data, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  })
    .then((responce) => {
      message.success(responce.data.msg);
    })
    .catch((error) => {
      message.error(error);
    });
};

const File = () => {
  return (
    <div className="App">
      <div>
        <Row align="middle" justify="center">
          <Col span={6}>
            <Form name="file-upload-form" onFinish={SubmitFile}>
              <Form.Item name="imageFile" type="primary">
                <Upload
                  multiple
                  listType="picture"
                  accept=".xlsx"
                  showUploadList={false}
                >
                  <Button icon={<UploadOutlined />}>Select .XLSX File</Button>
                </Upload>
              </Form.Item>
              <Form.Item>
                <Button type="primary" htmlType="submit">
                  Upload
                </Button>
              </Form.Item>
            </Form>
          </Col>
        </Row>
        <div className="container">
          <Table />
        </div>
      </div>
    </div>
  );
};

export default File;
